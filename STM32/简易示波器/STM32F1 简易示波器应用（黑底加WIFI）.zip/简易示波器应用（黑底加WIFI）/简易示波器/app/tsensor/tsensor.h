#ifndef _tsensor_H
#define _tsensor_H
#include "sys.h"
#include "delay.h"

void T_adc_init(void);
int Get_Temper(void);	   //��ȡ�ڲ��¶�ֵ	



#endif

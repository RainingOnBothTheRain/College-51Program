#ifndef _sta_tcpclent_test_H
#define _sta_tcpclent_test_H


#include "system.h"


#define User_ESP8266_SSID	  "123"	      //?????????
#define User_ESP8266_PWD	  "18390945552"	  //?????????

#define User_ESP8266_TCPServer_IP	  "192.168.191.3"	  //????????IP
#define User_ESP8266_TCPServer_PORT	  "10008"	  //??????????


extern volatile uint8_t TcpClosedFlag;  //����һ��ȫ�ֱ���


void ESP8266_STA_TCPClient_Test(void);



#endif

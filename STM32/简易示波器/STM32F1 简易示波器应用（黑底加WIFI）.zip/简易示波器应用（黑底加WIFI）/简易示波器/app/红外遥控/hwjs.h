#ifndef _hwjs_H
#define _hwjs_H
#include "sys.h"
#include "delay.h"
void hwjs_init(void);
u8 HW_jssj(void);

//����ȫ�ֱ���
extern u32 hw_jsm;
extern u8  hw_jsbz;



#endif

#ifndef _displaycanshu_H
#define _displaycanshu_H
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "button.h"
#include "lcd_driver.h"
#include "gui.h"
#include "tim.h"
#include "stm32f10x_it.h"
#include "systeminit.h"
#include "adc.h"
#include "dac.h"

void displaycanshu();
#endif

#include "displaycanshu.h"
u8 vpp_buf[6];
u8 VMAX_buf[6];
u8 frequency_buf[7];
void displaycanshu()
{
			/**********************��ʾ���ֵ**************************************/
					vpp_buf[0]=vpp/10000+0x30;
					vpp_buf[1]=vpp%10000/1000+0x30;		
					vpp_buf[2]=vpp%10000%1000/100+0x30;
					vpp_buf[3]=vpp%10000%1000%100/10+0x30;
					vpp_buf[4]=vpp%10000%1000%100%10+0x30;
					vpp_buf[5]='\0';
						
					GUI_Show12ASCII(0,224,"Vpp=",POINT_COLOR,WHITE);
					GUI_Show12ASCII(30,224,vpp_buf,POINT_COLOR,WHITE);
					GUI_Show12ASCII(70,224,"mv",POINT_COLOR,WHITE);
			/********************��ʾ���ֵ**************************************/
					VMAX_buf[0]=(u16)Vmax/10000+0x30;
					VMAX_buf[1]=(u16)Vmax%10000/1000+0x30;		
					VMAX_buf[2]=(u16)Vmax%10000%1000/100+0x30;
					VMAX_buf[3]=(u16)Vmax%10000%1000%100/10+0x30;
					VMAX_buf[4]=(u16)Vmax%10000%1000%100%10+0x30;
					VMAX_buf[5]='\0';
					GUI_Show12ASCII(90,224,"Vmax=",POINT_COLOR,WHITE);
					GUI_Show12ASCII(130,224,VMAX_buf,POINT_COLOR,WHITE);
					GUI_Show12ASCII(170,224,"mv",POINT_COLOR,WHITE);
					
		
					frequency_buf[0]=(u16)(frequency/1000000+0x30);
					frequency_buf[1]=(u16)(frequency/100000%10+0x30);
					frequency_buf[2]=(u16)(frequency/10000%10+0x30);	
					frequency_buf[3]=(u16)(frequency/1000%10+0x30);
					frequency_buf[4]=(u16)(frequency/100%10+0x30);
					frequency_buf[5]=(u16)(frequency/10%10+0x30);
					frequency_buf[6]=(u16)(frequency%10+0x30);
					GUI_Show12ASCII(200,224,"f=",POINT_COLOR,WHITE);
					GUI_Show12ASCII(212,224,frequency_buf,POINT_COLOR,WHITE);
					GUI_Show12ASCII(300,224,"Hz",POINT_COLOR,WHITE);	
}
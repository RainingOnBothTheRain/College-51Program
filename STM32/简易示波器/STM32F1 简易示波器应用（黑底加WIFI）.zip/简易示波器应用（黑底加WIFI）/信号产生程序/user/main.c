

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "tim.h"
int main(void)
{	
	u32 i=0;
	delay_init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	uart_init(9600);
	led_init();
	tim3_init(1000,35999);  //��ʱʱ��0.5s ����1hz	  
	while(1)
	{
		i++;
		if(i>500000)
		{
			led0=1;	
			if(i>1000000)i=0;
		}
		else
		{
			led0=0;
		}	  				
	}	
}

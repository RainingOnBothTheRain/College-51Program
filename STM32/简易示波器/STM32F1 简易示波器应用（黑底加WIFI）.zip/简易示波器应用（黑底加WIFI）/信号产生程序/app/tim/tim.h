#ifndef _tim_H
#define _tim_H
#include "sys.h"
#include "delay.h"
void tim3_init(u32 arr,u32 pre);
void TIM3_IRQHandler(void);




#endif
